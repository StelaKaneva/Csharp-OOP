﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02.VehicleExtension.Contracts
{
    public interface IRefuelable
    {
        void Refuel(double liters);
    }
}
