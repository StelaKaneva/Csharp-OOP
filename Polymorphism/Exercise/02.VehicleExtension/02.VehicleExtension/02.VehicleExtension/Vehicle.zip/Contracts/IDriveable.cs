﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02.VehicleExtension.Contracts
{
    public interface IDriveable
    {
        string Drive(double distance);
    }
}
