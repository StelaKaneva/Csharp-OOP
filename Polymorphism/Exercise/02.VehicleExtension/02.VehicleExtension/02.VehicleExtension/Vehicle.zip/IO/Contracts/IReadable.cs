﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02.VehicleExtension.IO.Contracts
{
    public interface IReadable
    {
        string ReadLine();
    }
}
