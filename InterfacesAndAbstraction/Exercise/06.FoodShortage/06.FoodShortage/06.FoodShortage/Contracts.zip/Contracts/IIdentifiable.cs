﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.FoodShortage.Contracts
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
