﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Telephony.Contracts
{
    public interface IBrowsable
    {
        public string Browse(string url);

    }
}
