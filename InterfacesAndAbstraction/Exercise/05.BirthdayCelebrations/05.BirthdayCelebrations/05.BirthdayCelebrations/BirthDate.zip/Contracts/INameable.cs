﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BirthdayCelebrations.Contracts
{
    public interface INameable
    {
        string Name { get; }
    }
}
