﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.ShoppingSpree.Common
{
    public static class GlobalConstants
    {
        public const string EMPTY_NAME_EXC_MSG = "Name cannot be empty";
        public const string NEGATIVE_MONEY_EXC_MSG = "Money cannot be negative";
    }
}
